import './style.css'

const ACCREDITED_MAJORS = [
  'Accounting',
  'Finance',
  'Accounting Information Systems',
  'Internal Audit',
]

const VALID_AUTHORIZATIONS = [
  'Citizen',
  'Permanent Resident',
  'F-1 OPT',
  'Verified Work Visa',
]

const REQUIRED_COURSES = ['Auditing', 'AIS', 'Internal Controls']

const TARGET_INTAKE_YEAR = new Date().getFullYear() + 1

function render() {
  const app = document.querySelector('#app')
  app.innerHTML = `
    <section class="triage-card" aria-labelledby="page-title">
      <h1 id="page-title">Candidate Knockout Triage</h1>
      <p class="subtitle">Enter a candidate's qualification profile for an instant eligibility decision.</p>

      <form id="triage-form" novalidate>
        <div class="field" id="field-major">
          <label for="major">Degree Major <span class="hint">(must be an accredited accounting/finance discipline)</span></label>
          <select id="major" name="major" required>
            <option value="" selected disabled>Select a major…</option>
            ${ACCREDITED_MAJORS.map((m) => `<option value="${m}">${m}</option>`).join('')}
            <option value="other">Other / Not accredited</option>
          </select>
        </div>

        <div class="field" id="field-grad-year">
          <label for="grad-year">Graduation Year <span class="hint">(must be within the current academic cycle, ≤ 1 year from ${TARGET_INTAKE_YEAR})</span></label>
          <input id="grad-year" name="grad-year" type="number" min="1900" max="2100" inputmode="numeric" placeholder="e.g. ${TARGET_INTAKE_YEAR}" required />
        </div>

        <div class="field" id="field-authorization">
          <label for="authorization">Work Authorization <span class="hint">(valid, unexpired domestic eligibility)</span></label>
          <select id="authorization" name="authorization" required>
            <option value="" selected disabled>Select authorization…</option>
            ${VALID_AUTHORIZATIONS.map((a) => `<option value="${a}">${a}</option>`).join('')}
            <option value="other">Other / Unverified</option>
          </select>
        </div>

        <div class="field" id="field-coursework">
          <label>Completed Foundational Coursework <span class="hint">(at least one of: Auditing, AIS, or Internal Controls)</span></label>
          <div class="checkbox-group">
            ${REQUIRED_COURSES.map(
              (c) => `
              <label>
                <input type="checkbox" name="coursework" value="${c}" />
                <span>${c}</span>
              </label>`
            ).join('')}
          </div>
        </div>

        <div class="submit-row">
          <button type="submit" class="submit-btn">Evaluate Candidate</button>
        </div>
      </form>

      <div class="result" id="result" aria-live="polite"></div>
    </section>
  `

  const form = document.querySelector('#triage-form')
  form.addEventListener('submit', (event) => {
    event.preventDefault()
    evaluate()
  })
}

function evaluate() {
  const major = document.querySelector('#major').value
  const gradYearRaw = document.querySelector('#grad-year').value.trim()
  const authorization = document.querySelector('#authorization').value
  const coursework = Array.from(
    document.querySelectorAll('input[name="coursework"]:checked')
  ).map((el) => el.value)

  // Reset any prior invalid field styling.
  document
    .querySelectorAll('.field.invalid')
    .forEach((f) => f.classList.remove('invalid'))

  const failures = []

  // Required-input validation: empty fields are flagged as unmet criteria
  // rather than throwing exceptions, so user input is preserved.
  const gradYear = Number.parseInt(gradYearRaw, 10)
  const gradYearValid =
    gradYearRaw !== '' && !Number.isNaN(gradYear) && String(gradYear) === gradYearRaw

  // 1. Degree Alignment
  if (!ACCREDITED_MAJORS.includes(major)) {
    failures.push('Degree Alignment: major is not within accredited accounting/finance disciplines.')
    flagField('field-major')
  }

  // 2. Graduation Timeline (within current academic cycle, <= 1 year from target intake)
  if (!gradYearValid || gradYear < TARGET_INTAKE_YEAR - 1 || gradYear > TARGET_INTAKE_YEAR + 1) {
    failures.push(
      `Graduation Timeline: graduation year must be within the current academic cycle (between ${TARGET_INTAKE_YEAR - 1} and ${TARGET_INTAKE_YEAR + 1}).`
    )
    flagField('field-grad-year')
  }

  // 3. Work Authorization
  if (!VALID_AUTHORIZATIONS.includes(authorization)) {
    failures.push('Work Authorization: no valid, unexpired domestic employment eligibility on record.')
    flagField('field-authorization')
  }

  // 4. Coursework Prerequisite (at least one foundational governance/assurance course)
  if (!coursework.some((c) => REQUIRED_COURSES.includes(c))) {
    failures.push('Coursework Prerequisite: no completed foundational governance or assurance course (Auditing, AIS, or Internal Controls).')
    flagField('field-coursework')
  }

  const eligible = failures.length === 0
  renderResult(eligible, failures)
}

function flagField(id) {
  const field = document.getElementById(id)
  if (field) field.classList.add('invalid')
}

function renderResult(eligible, failures) {
  const result = document.querySelector('#result')
  const badge = eligible
    ? '<span class="badge eligible">Eligible</span>'
    : '<span class="badge ineligible">Ineligible</span>'

  const headline = eligible
    ? 'Candidate passes all four knockout criteria.'
    : 'Candidate did not meet the following requirements:'

  const failuresBlock = eligible
    ? ''
    : `<ul class="failures">${failures.map((f) => `<li>${escapeHtml(f)}</li>`).join('')}</ul>`

  const note = eligible
    ? '<p class="result-note">Profile meets the minimum qualification threshold for this intake cycle.</p>'
    : '<p class="result-note">Input fields are preserved — adjust and re-evaluate if needed.</p>'

  result.innerHTML = `
    <div>${badge}</div>
    <p class="headline">${headline}</p>
    ${failuresBlock}
    ${note}
  `
  result.classList.add('visible')
}

function escapeHtml(str) {
  const div = document.createElement('div')
  div.textContent = str
  return div.innerHTML
}

render()
